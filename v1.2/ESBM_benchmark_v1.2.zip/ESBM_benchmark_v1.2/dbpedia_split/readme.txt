Fold	Training.txt	Validation.txt	Test.txt
Fold0	S0, S1, S2	S3	S4
Fold1	S1, S2, S3	S4	S0
Fold2	S2, S3, S4	S0	S1
Fold3	S3, S4, S0	S1	S2
Fold4	S4, S0, S1	S2	S3
